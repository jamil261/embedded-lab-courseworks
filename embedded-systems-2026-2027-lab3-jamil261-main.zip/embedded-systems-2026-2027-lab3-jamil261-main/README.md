LAB 3 COMPLETED

the code makes the leds flash from 1-5 and if b1 is pressed it revereses the order.
