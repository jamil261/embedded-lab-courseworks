/* ------------------------------------------
        ECS642/ECS714 Lab 3 - Activity 2
      -------------------------------------------- */
  
#include <stdbool.h>
#include <stdint.h>
#include <MKL28Z7.h>
#include "..\inc\SysTick.h"
#include "..\inc\button.h"
#include "..\inc\led.h"

/*----------------------------------------------------------------------------
  Variables for communication
*----------------------------------------------------------------------------*/
bool pressedB1_ev;  // Set by task1 (polling) and cleared by task2

/*----------------------------------------------------------------------------
  task1pollB1
  
  This task polls button B1 with debouncing logic.
*----------------------------------------------------------------------------*/
int b1State;        
int b1BounceCount;

void initTask1() {
    b1State = BOPEN;
    pressedB1_ev = false; 
    b1BounceCount = 0;
}

void task1pollB1() {
    if (b1BounceCount > 0) b1BounceCount--;
    switch (b1State) {
        case BOPEN:
            if (isPressed(B1)) {
                b1State = BCLOSED;
                pressedB1_ev = true; 
            }
            break;

        case BCLOSED:
            if (!isPressed(B1)) {
                b1State = BBOUNCE;
                b1BounceCount = BOUNCEDELAY;
            }
            break;

        case BBOUNCE:
            if (isPressed(B1)) {
                b1State = BCLOSED;
            }
            else if (b1BounceCount == 0) {
                b1State = BOPEN;
            }
            break;
    }                
}

/*----------------------------------------------------------------------------
  Activity 2: State Machine & nextLit function
*----------------------------------------------------------------------------*/
typedef enum {
    MoveLit1to5,
    MoveLit5to1
} LEDState_t;

LEDState_t stateMoveLED;
int c;          // Counter variable 'c' for the 1-second interval (100 ticks * 10ms)
int currentLED; // Integer recording which LED is currently lit

// nextLit function: updates the integer tracking the lit LED based on direction
void nextLit(int direction) {
    ledOnOff(currentLED, LED_OFF); // Turn off current LED
    
    if (direction == 1) { // Moving from LED1 to LED5
        if (currentLED == LED5) {
            currentLED = LED1;  // LED5 to LED1
        } else {
            currentLED++;
        }
    } else { //  LED5 to LED1
        if (currentLED == LED1) {
            currentLED = LED5; 
        } else {
            currentLED--;
        }
    }
    
    ledOnOff(currentLED, LED_ON);  // Turn on the new lit LED
}

void initTask2() {
    stateMoveLED = MoveLit1to5;
    c = 100;                    // Initial counter valu
    currentLED = LED1;          // Start with LED1 lit
    
    //  all LEDs are off, then turn on LED1
    for (int i = LED1; i <= LED5; i++) {
        ledOnOff(i, LED_OFF);
    }
    ledOnOff(currentLED, LED_ON);
}

void task2MoveLEDs() {
    // Decrement counter every loop cycle -10ms
    if (c > 0) {
        c--;
    }

    switch (stateMoveLED) {
        case MoveLit1to5:
            // Check if B1 was pressed to transition state
            if (pressedB1_ev) {
                pressedB1_ev = false;       
                stateMoveLED = MoveLit5to1;
            }
            
            // When c == 0 (1 second completed), call nextLit(1to5) and reset c = 100
            if (c == 0) {
                nextLit(1); 
                c = 100;                    // Reset counter
            }
            break;

        case MoveLit5to1:
            // Check if B1 was pressed to transition state
            if (pressedB1_ev) {
                pressedB1_ev = false;       
                stateMoveLED = MoveLit1to5;
            }
            
            // When c == 0 (1 second completed), call nextLit(5to1) and reset c = 100
            if (c == 0) {
                nextLit(-1);
                c = 100;                    // Reset counter
            }
            break;
    }
}

/*----------------------------------------------------------------------------
  MAIN function
*----------------------------------------------------------------------------*/
int main (void) {
    configureLEDs();                // Configure LED1-5 using GPIO
    configureButtons(B1, false);    // Configure button B1 for polling
    initTask1();                    // Initialise task1 state
    initTask2();                    // Initialise task2 state 
    Init_SysTick(1000);             // Initialise SysTick every 1ms
    waitSysTickCounter(10);
    
    while (1) {                     // Runs forever
        task1pollB1();
        task2MoveLEDs();
        waitSysTickCounter(10);     // Cycle every 10 ms
    }
}