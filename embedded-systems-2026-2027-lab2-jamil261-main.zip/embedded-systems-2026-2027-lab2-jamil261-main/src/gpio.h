#ifndef GPIO_H
#define GPIO_H

// Bit mask 
#define MASK(x) (1UL << (x))


#define RED_LED_POS   (29)   // port e is pin 29
#define GREEN_LED_POS (4)    // port c pin 4
#define BLUE_LED_POS  (31)   // port e pin 31

// logic levels
#define OFF 0
#define ON  1

// time constants 
#define PERIOD_5S 500 // 5 seconds 
#define PERIOD_3S 300 // 3 seconds 

#endif



//Activity 3 code

// #ifndef GPIO_H
// #define GPIO_H

// Bit mask 
// #define MASK(x) (1UL << (x))

// Freedom KL28Z LED Pin Assignments
// #define RED_LED_POS   (29)   // port E pin 29
// #define GREEN_LED_POS (4)    // port C pin 4
// #define BLUE_LED_POS  (31)   // port E pin 31

// logic levels
// #define OFF 0
// #define ON  1

// time constants
// #define PERIOD_2S 200  // 2.0 seconds[cite: 3]
// #define PERIOD_1S 100  // 1.0 second[cite: 3]

// state cpnstants
// #define STATE_RED     0
// #define STATE_GREEN   1
// #define STATE_BLUE    2
// #define STATE_YELLOW  3
// #define STATE_CYAN    4
// #define STATE_MAGENTA 5
// #define STATE_WHITE   6

// #endif