#include <MKL28Z7.h>
#include "SysTick.h"
#include "gpio.h"

/* the functiosn */
void setRedLED(int onOff);
void setGreenLED(int onOff);
void setBlueLED(int onOff);
void Task1Red(void);
void Task2Green(void);
void configure(void);

/* red led 5s on 5s off*/
int redState = ON;
int redCount = PERIOD_5S;

/* green led 3s on 3s off */
int greenState = ON;
int greenCount = PERIOD_3S;

void setRedLED(int onOff) {
    if (onOff == ON)  { PTE->PCOR = MASK(RED_LED_POS); }
    if (onOff == OFF) { PTE->PSOR = MASK(RED_LED_POS); }
}

void setGreenLED(int onOff) {
    if (onOff == ON)  { PTC->PCOR = MASK(GREEN_LED_POS); }
    if (onOff == OFF) { PTC->PSOR = MASK(GREEN_LED_POS); }
}

void setBlueLED(int onOff) {
    if (onOff == ON)  { PTE->PCOR = MASK(BLUE_LED_POS); }
    if (onOff == OFF) { PTE->PSOR = MASK(BLUE_LED_POS); }
}

/* Statemachine for red LED */
void Task1Red(void) {
    if (redCount > 0) redCount--;

    if (redCount == 0) {
        if (redState == ON) {
            setRedLED(OFF);
            redState = OFF;
        } else {
            setRedLED(ON);
            redState = ON;
        }
        redCount = PERIOD_5S;
    }
}

/* state machine green LED */
void Task2Green(void) {
    if (greenCount > 0) greenCount--;

    if (greenCount == 0) {
        if (greenState == ON) {
            setGreenLED(OFF);
            greenState = OFF;
        } else {
            setGreenLED(ON);
            greenState = ON;
        }
        greenCount = PERIOD_3S;
    }
}

void configure(void) {
    /* port c and e clock cycle */
    PCC_PORTC |= PCC_CLKCFG_CGC(1);
    PCC_PORTE |= PCC_CLKCFG_CGC(1);

    /* setting pin MUX to GPIO */
    PORTE->PCR[RED_LED_POS] &= ~PORT_PCR_MUX_MASK;
    PORTE->PCR[RED_LED_POS] |= PORT_PCR_MUX(1);
    PORTC->PCR[GREEN_LED_POS] &= ~PORT_PCR_MUX_MASK;
    PORTC->PCR[GREEN_LED_POS] |= PORT_PCR_MUX(1);
    PORTE->PCR[BLUE_LED_POS] &= ~PORT_PCR_MUX_MASK;
    PORTE->PCR[BLUE_LED_POS] |= PORT_PCR_MUX(1);

    /*  direction to output */
    PTE->PDDR |= MASK(RED_LED_POS) | MASK(BLUE_LED_POS);
    PTC->PDDR |= MASK(GREEN_LED_POS);

    /* initally leds are off */
    PTE->PSOR = MASK(RED_LED_POS) | MASK(BLUE_LED_POS);
    PTC->PSOR = MASK(GREEN_LED_POS);
}

int main(void) {
    configure();

    /* inintal state of red ang green is yellow */
    setRedLED(ON);
    setGreenLED(ON);
    setBlueLED(OFF);

    Init_SysTick(1000);
    waitSysTickCounter(10);

    while (1) {
        Task1Red();    /* task 1  every 10ms */
        Task2Green();  /* task 2  every 10ms */
        waitSysTickCounter(10);
    }
}

// #include <MKL28Z7.h>
// #include "SysTick.h"
// #include "gpio.h"

// fucntions
// void setRedLED(int onOff);
// void setGreenLED(int onOff);
// void setBlueLED(int onOff);
// void setRGB(int red, int green, int blue);
// void every10ms(void);
// void configure(void);

// global Variables
// int state = STATE_RED;
// int count = PERIOD_2S;

// void setRedLED(int onOff) {
//     if (onOff == ON)  { PTE->PCOR = MASK(RED_LED_POS); }
//     if (onOff == OFF) { PTE->PSOR = MASK(RED_LED_POS); }
// }

// void setGreenLED(int onOff) {
//     if (onOff == ON)  { PTC->PCOR = MASK(GREEN_LED_POS); }
//     if (onOff == OFF) { PTC->PSOR = MASK(GREEN_LED_POS); }
// }

// void setBlueLED(int onOff) {
//     if (onOff == ON)  { PTE->PCOR = MASK(BLUE_LED_POS); }
//     if (onOff == OFF) { PTE->PSOR = MASK(BLUE_LED_POS); }
// }

// void setRGB(int red, int green, int blue) {
//     setRedLED(red);
//     setGreenLED(green);
//     setBlueLED(blue);
// }

// void every10ms(void) {
//     if (count > 0) count--;

//     if (count == 0) {
//         switch (state) {
//             case STATE_RED:
//                 setRGB(OFF, ON, OFF); // Switch to Green 
//                 state = STATE_GREEN;
//                 count = PERIOD_2S;
//                 break;

//             case STATE_GREEN:
//                 setRGB(OFF, OFF, ON); // Switch to Blue 
//                 state = STATE_BLUE;
//                 count = PERIOD_2S;
//                 break;

//             case STATE_BLUE:
//                 setRGB(ON, ON, OFF);  // Switch to Yellow 
//                 state = STATE_YELLOW;
//                 count = PERIOD_1S;
//                 break;

//             case STATE_YELLOW:
//                 setRGB(OFF, ON, ON);  // Switch to Cyan 
//                 state = STATE_CYAN;
//                 count = PERIOD_1S;
//                 break;

//             case STATE_CYAN:
//                 setRGB(ON, OFF, ON);  // Switch to Magenta 
//                 state = STATE_MAGENTA;
//                 count = PERIOD_1S;
//                 break;

//             case STATE_MAGENTA:
//                 setRGB(ON, ON, ON);   // Switch to White 
//                 state = STATE_WHITE;
//                 count = PERIOD_1S;
//                 break;

//             case STATE_WHITE:
//                 setRGB(ON, OFF, OFF); // Switch back to Red 
//                 state = STATE_RED;
//                 count = PERIOD_2S;
//                 break;
//         }
//     }
// }

// void configure(void) {
//     PCC_PORTC |= PCC_CLKCFG_CGC(1);
//     PCC_PORTE |= PCC_CLKCFG_CGC(1);

//     PORTE->PCR[RED_LED_POS] &= ~PORT_PCR_MUX_MASK;
//     PORTE->PCR[RED_LED_POS] |= PORT_PCR_MUX(1);
//     PORTC->PCR[GREEN_LED_POS] &= ~PORT_PCR_MUX_MASK;
//     PORTC->PCR[GREEN_LED_POS] |= PORT_PCR_MUX(1);
//     PORTE->PCR[BLUE_LED_POS] &= ~PORT_PCR_MUX_MASK;
//     PORTE->PCR[BLUE_LED_POS] |= PORT_PCR_MUX(1);

//     PTE->PDDR |= MASK(RED_LED_POS) | MASK(BLUE_LED_POS);
//     PTC->PDDR |= MASK(GREEN_LED_POS);

//     PTE->PSOR = MASK(RED_LED_POS) | MASK(BLUE_LED_POS);
//     PTC->PSOR = MASK(GREEN_LED_POS);
// }

// int main(void) {
//     configure();
//     
//     setRGB(ON, OFF, OFF); // Start with Red

//     Init_SysTick(1000);
//     waitSysTickCounter(10);

//     while (1) {
//         every10ms();
//         waitSysTickCounter(10);
//     }
// }