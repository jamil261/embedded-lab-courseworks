# Lab 2 Starter Code
This code is is for both activity 3 (7 different color states,. its at the bottom of the main.c and gpio.h in the comments)

the activity 5 code (combining 2 state machines) is the uncommented code.
