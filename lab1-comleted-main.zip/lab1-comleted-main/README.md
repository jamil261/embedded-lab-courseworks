Embedded Systems Lab 1
This project implements a cyclic RGB LED system on the KL28Z development board.

The program continuously cycles through three LED colours:

Red for 2 seconds

Green for 2 seconds

Blue for 2 seconds

All LEDs off for 4 seconds

The complete cycle takes 10 seconds and then repeats continuously.

The program uses a 10 ms cyclic timer to control the LED states.
