demonstrated activity 1 and 2

act 2 has the changed code

i attached the oscillsocpe trace and the calculations
